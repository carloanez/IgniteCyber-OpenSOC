# Code of Conduct (Short Version)

We are committed to a welcoming, harassment‑free community.
- Be respectful and inclusive.
- No personal attacks, hate speech, or harassment.
- Assume good intent; focus on solutions.

Report issues to the maintainers at conduct@ignitecyber.academy.

(Modeled after the Contributor Covenant v2.1)
