# OpenSOC Contributor Agreement (Summary)

By contributing, you confirm that:
1) Your contribution is voluntary and unpaid.
2) You grant a perpetual, worldwide, royalty‑free license for use and distribution.
3) You will not submit export‑controlled, classified, or proprietary materials.
4) You agree to comply with applicable laws and this project's Code of Conduct.

> For substantial code contributions, maintainers may request a signed DCO/CLA addendum.
