# Security Policy

This repo is for training/demo content only.

- **Do not** submit exploits targeting live systems.
- **Do not** upload real PII or production data.
- Report sensitive security issues privately to: security@ignitecyber.academy.
