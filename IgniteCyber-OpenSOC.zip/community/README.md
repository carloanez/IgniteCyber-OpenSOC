# Community

- Join **Discord/Slack** (invite link TBD)
- Participate in monthly **OpenSOC Labs**
- Help us connect with **SANS Community Chapters** for co-hosted 'Community Nights'
