# Docker Stack
Demo-grade stack for local labs. Edit `.env` and service configs as needed.
