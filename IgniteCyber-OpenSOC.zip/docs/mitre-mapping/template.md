# MITRE ATT&CK Mapping Template

- **Technique ID(s):** e.g., T1059.001 (PowerShell)
- **Tactic(s):** Execution
- **Data Sources:** Sysmon Event ID 1/3, Zeek conn.log, Wazuh alerts.json
- **Detection Logic Summary:** (queries/rules overview)
- **Sigma/Query:** (link or inline code block)
- **False Positives:** (notes)
- **Validation Steps:** (how to simulate and verify)
- **References:** (docs, blog posts)
