# Setup Guides

- [Docker Quickstart](./docker-quickstart.md)
- [Kibana Access](./kibana.md)
- [Wazuh Enrollment](./wazuh-agent.md)
