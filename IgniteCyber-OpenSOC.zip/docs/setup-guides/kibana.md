# Kibana Access

- URL: http://localhost:5601
- Import sample dashboards from `docs/dashboards/`
- Create index pattern for `wazuh-*` and `zeek-*`
