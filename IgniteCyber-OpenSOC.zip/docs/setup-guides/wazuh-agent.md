# Wazuh Agent Enrollment (Demo)

For a local training VM:
1. Install Wazuh agent
2. Set manager IP to host IP
3. Start the service and generate benign logs
