# Module0 Soc Foundations

Learning objectives, labs, and ATT&CK mappings.
