# Module3 Incident Response

Learning objectives, labs, and ATT&CK mappings.
