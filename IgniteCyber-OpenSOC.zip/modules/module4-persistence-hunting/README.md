# Module4 Persistence Hunting

Learning objectives, labs, and ATT&CK mappings.
