# LAB-1.3 — First Detection (Suspicious PowerShell / Sigma)

External archives:

- [host] PowerShell HTTP Listener
  - https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/atomic/windows/execution/host/psh_powershell_httplistener.zip
