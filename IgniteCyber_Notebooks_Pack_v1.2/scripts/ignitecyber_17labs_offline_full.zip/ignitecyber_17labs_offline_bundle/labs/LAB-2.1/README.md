# LAB-2.1 — Phishing Triage (Elastic Casebook)

External archives:

- [host] UI Prompt For Credentials (phish-style prompt)
  - https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/atomic/windows/credential_access/host/psh_input_capture_promptforcreds.zip
