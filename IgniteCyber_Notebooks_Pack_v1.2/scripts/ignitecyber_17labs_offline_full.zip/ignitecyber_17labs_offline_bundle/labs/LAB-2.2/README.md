# LAB-2.2 — Maldoc/Macro Analysis (IOC extraction)

External archives:

- [host] DCOM ExecuteExcel4Macro (Host)
  - https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/atomic/windows/lateral_movement/host/covenant_dcom_executeexcel4macro_allowed.zip
- [network] DCOM ExecuteExcel4Macro (Network)
  - https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/atomic/windows/lateral_movement/network/covenant_dcom_executeexcel4macro_allowed.zip
