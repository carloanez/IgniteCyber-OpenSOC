# LAB-2.3 — LOLBAS mshta Proxy Execution (T1218.005)

External archives:

- [host] mshta javascript GetObject .sct (T1218.005)
  - https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/atomic/windows/defense_evasion/host/cmd_mshta_javascript_getobject_sct.zip
