# LAB-2.4 — BITSADMIN Download (T1197)

External archives:

- [host] bitsadmin download PowerShell script
  - https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/atomic/windows/defense_evasion/host/cmd_bitsadmin_download_psh_script.zip
