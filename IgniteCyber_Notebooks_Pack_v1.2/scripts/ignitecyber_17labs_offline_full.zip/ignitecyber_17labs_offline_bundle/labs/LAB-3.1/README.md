# LAB-3.1 — C2 Beacon Investigation (Cobalt Strike)

External archives:

- [host] APT Simulator Cobalt Strike
  - https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/atomic/windows/other/aptsimulator_cobaltstrike.zip
