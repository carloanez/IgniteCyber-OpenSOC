# LAB-3.2 — Lateral Movement (WinRM + Schtasks)

External archives:

- [host] Covenant PowerShell Remoting Command (Host)
  - https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/atomic/windows/lateral_movement/host/covenant_psremoting_command.zip
- [network] Covenant PowerShell Remoting Command (Network)
  - https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/atomic/windows/lateral_movement/network/covenant_psremoting_command.zip
- [host] Remote Scheduled Task Modification (Host)
  - https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/atomic/windows/lateral_movement/host/schtask_modification.zip
- [network] Remote Scheduled Task Modification (Network)
  - https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/atomic/windows/lateral_movement/network/schtask_modification.zip
