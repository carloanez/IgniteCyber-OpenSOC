# LAB-3.3 — Timeline Reconstruction (Elastic)

External archives:

- [host] Log4Shell Security Auditing (Java serialized object)
  - https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/compound/Log4Shell/securityauditing_log4shell_cve2021_44228_java_serialized_object.zip
- [host] Log4Shell Sysmon (Java serialized object)
  - https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/compound/log4shell/sysmon_log4shell_cve2021_44228_java_serialized_object.zip
- [network] Log4Shell PCAP (JNDI reference)
  - https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/compound/Log4Shell/pcap_log4shell_cve2021_44228_jndi_reference.zip
