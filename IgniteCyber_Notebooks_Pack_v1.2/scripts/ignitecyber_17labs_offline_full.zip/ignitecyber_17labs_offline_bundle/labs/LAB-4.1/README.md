# LAB-4.1 — Persistence Hunt (RunKeys + Schtasks)

External archives:

- [host] Registry Run Keys (Standard User)
  - https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/atomic/windows/persistence/host/empire_persistence_registry_modification_run_keys_standard_user.zip
- [host] Scheduled Tasks Creation (Standard User)
  - https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/atomic/windows/persistence/host/empire_schtasks_creation_standard_user.zip
- [host] Scheduled Tasks Creation/Execution (Elevated User)
  - https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/atomic/windows/persistence/host/empire_schtasks_creation_execution_elevated_user.zip
