# LAB-4.2 — Credential Access Hunt (T1003.003 - LSASS Memory / Rubeus-themed)

External archives:

- [host] (Recommended) DCSync-style credential access (Mordor)
  - https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/small/windows/credential_access/host/empire_dcsync.zip
