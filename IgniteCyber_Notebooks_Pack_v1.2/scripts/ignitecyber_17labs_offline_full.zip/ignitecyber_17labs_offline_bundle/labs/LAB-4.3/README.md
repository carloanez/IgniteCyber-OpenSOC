# LAB-4.3 — Threat Hunting Workflow (ELK)

External archives:

- [host] DLL Injection (LoadLibrary/CreateRemoteThread)
  - https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/atomic/windows/defense_evasion/host/empire_dllinjection_LoadLibrary_CreateRemoteThread.zip
- [host] DCOM ShellWindows Stager (Host)
  - https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/atomic/windows/lateral_movement/host/empire_dcom_shellwindows_stager.zip
- [network] DCOM ShellWindows Stager (Network)
  - https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/atomic/windows/lateral_movement/network/empire_dcom_shellwindows_stager.zip
