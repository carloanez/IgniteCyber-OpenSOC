# LAB-5.1 — AI Triage Assistant (Validated Summaries)

External archives:

- [host] APT Simulator Cobalt Strike (reuse)
  - https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/atomic/windows/other/aptsimulator_cobaltstrike.zip
