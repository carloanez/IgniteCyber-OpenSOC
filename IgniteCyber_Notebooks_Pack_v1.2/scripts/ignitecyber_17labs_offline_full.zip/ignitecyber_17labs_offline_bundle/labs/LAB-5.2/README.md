# LAB-5.2 — AI Assisted Sigma Authoring (Unit Tests)

External archives:

- [host] bitsadmin download PowerShell script (reuse)
  - https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/atomic/windows/defense_evasion/host/cmd_bitsadmin_download_psh_script.zip
