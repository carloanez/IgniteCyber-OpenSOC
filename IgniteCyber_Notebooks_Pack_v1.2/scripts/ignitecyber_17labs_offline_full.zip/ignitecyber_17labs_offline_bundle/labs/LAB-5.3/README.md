# LAB-5.3 — AI Assisted ATT&CK Mapping Report

External archives:

- [host] Registry Run Keys (Standard User) (reuse)
  - https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/atomic/windows/persistence/host/empire_persistence_registry_modification_run_keys_standard_user.zip
- [host] PowerShell HTTP Listener (reuse)
  - https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/atomic/windows/execution/host/psh_powershell_httplistener.zip
