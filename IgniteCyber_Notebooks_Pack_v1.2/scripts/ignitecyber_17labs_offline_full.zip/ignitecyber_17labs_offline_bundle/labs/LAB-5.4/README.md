# LAB-5.4 — Capstone (CINDER JACKAL Investigation)

External archives:

- [host] APT Simulator Cobalt Strike
  - https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/atomic/windows/other/aptsimulator_cobaltstrike.zip
- [host] Scheduled Task Modification (Host)
  - https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/atomic/windows/lateral_movement/host/schtask_modification.zip
- [network] Scheduled Task Modification (Network)
  - https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/atomic/windows/lateral_movement/network/schtask_modification.zip
- [host] Registry Run Keys (Standard User)
  - https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/atomic/windows/persistence/host/empire_persistence_registry_modification_run_keys_standard_user.zip
